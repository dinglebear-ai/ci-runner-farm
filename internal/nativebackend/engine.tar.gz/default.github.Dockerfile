# ci-runner-farm runner image (starter). Edit this from the plugin UI
# (Settings -> Utilities -> CI Runner Farm -> Runner image builder), then Build,
# and point the IMAGE setting at the resulting tag.
#
# This is a minimal starting point: the stock self-hosted runner base plus a
# docker-in-docker readiness wrapper. Add whatever your CI needs (language
# runtimes, browsers, build tools) in the marked section below.
FROM myoung34/github-runner:latest

USER root
ENV DEBIAN_FRONTEND=noninteractive

# DinD needs a private cgroup-v2 domain before the base entrypoint starts
# dockerd. Keep registration/token handling in /entrypoint.sh and add only this
# pre-entrypoint bootstrap.
RUN printf '%s\n' \
  '#!/usr/bin/env bash' \
  'set -Eeuo pipefail' \
  'root=/sys/fs/cgroup' \
  'child="$root/unraid-init"' \
  'fail() { printf "[unraid-cgroup] %s\\n" "$*" >&2; exit 1; }' \
  '[ "$(id -u)" -eq 0 ] || fail "the cgroup bootstrap must run as root"' \
  '[ -r "$root/cgroup.controllers" ] || fail "cgroup v2 is not mounted at /sys/fs/cgroup"' \
  'path="$(cut -d: -f3 /proc/self/cgroup)"' \
  '[ "$path" = / ] || fail "DinD requires a private cgroup namespace (current path: ${path:-unknown})"' \
  '[ "$(cat "$root/cgroup.type")" = domain ] || fail "cgroup v2 root is not a domain"' \
  'mkdir -p "$child"' \
  'mapfile -t pids < "$root/cgroup.procs"' \
  'for preferred in 1 "$$"; do for pid in "${pids[@]}"; do [ "$pid" = "$preferred" ] || continue; printf "%s\\n" "$pid" > "$child/cgroup.procs" 2>/dev/null || true; done; done' \
  'for ((attempt=0; attempt<50; attempt++)); do' \
  '  mapfile -t pids < "$root/cgroup.procs"' \
  '  for pid in "${pids[@]}"; do case "$pid" in ""|*[!0-9]*) continue;; esac; printf "%s\\n" "$pid" > "$child/cgroup.procs" 2>/dev/null || true; done' \
  '  mapfile -t remaining < "$root/cgroup.procs"' \
  '  (( ${#remaining[@]} == 0 )) && break' \
  '  sleep 0.02' \
  'done' \
  '(( ${#remaining[@]} == 0 )) || fail "could not empty the cgroup namespace root before delegation"' \
  'read -r -a controllers < "$root/cgroup.controllers"' \
  '(( ${#controllers[@]} > 0 )) || fail "the cgroup v2 root exposes no controllers"' \
  'printf "+%s " "${controllers[@]}" > "$root/cgroup.subtree_control"' \
  '[ "$(cat "$root/cgroup.type")" = domain ] || fail "cgroup v2 root became non-domain during bootstrap"' \
  'grep -qw pids "$root/cgroup.subtree_control" || fail "the cgroup v2 pids controller was not delegated"' \
  > /usr/local/bin/unraid-cgroup-bootstrap.sh \
 && chmod +x /usr/local/bin/unraid-cgroup-bootstrap.sh
RUN printf '%s\n' \
  '#!/usr/bin/env bash' \
  'set -Eeuo pipefail' \
  'if [ -n "${KVM_GID:-}" ]; then' \
  '  [ -c /dev/kvm ] && [ "$(stat -c %g /dev/kvm)" = "$KVM_GID" ] || exit 1' \
  '  group_name="$(getent group "$KVM_GID" | cut -d: -f1 || true)"' \
  '  if [ -z "$group_name" ]; then group_name=host-kvm; groupadd -g "$KVM_GID" "$group_name"; fi' \
  '  usermod -aG "$group_name" runner' \
  'fi' \
  'if [ "${START_DOCKER_SERVICE:-false}" = true ]; then' \
  '  fail() { printf "[unraid-runner] %s\\n" "$*" >&2; exit 1; }' \
  '  [ "$(id -u)" -eq 0 ] || fail "DinD startup requires root before dropping privileges"' \
  '  [ -x /usr/bin/update-alternatives ] || fail "container alternatives tool is missing"' \
  '  for tool in iptables ip6tables; do' \
  '    [ -x "/usr/sbin/${tool}-nft" ] || fail "container nft alternative is missing: $tool"' \
  '    /usr/bin/update-alternatives --set "$tool" "/usr/sbin/${tool}-nft" || fail "container nft selection failed: $tool"' \
  '    "/usr/sbin/$tool" --version | grep -q "(nf_tables)" || fail "container nft backend verification failed: $tool"' \
  '  done' \
  '  /usr/local/bin/unraid-cgroup-bootstrap.sh' \
  'fi' \
  'exec /entrypoint.sh "$@"' \
  > /usr/local/bin/unraid-runner-entrypoint.sh \
 && chmod +x /usr/local/bin/unraid-runner-entrypoint.sh \
 && test -x /entrypoint.sh
ENTRYPOINT ["/usr/local/bin/unraid-runner-entrypoint.sh"]

# --- Add your packages / tools here ---
# RUN apt-get update && apt-get install -y --no-install-recommends <your-packages> \
#  && rm -rf /var/lib/apt/lists/*

# Pre-create the default CACHE_MOUNTS destinations as runner-owned. When these
# paths are absent from the image, Docker's bind-mount auto-creation makes the
# missing parent directories root-owned, and a non-root runner (RUN_AS_ROOT=false)
# can then no longer write beside them — e.g. rustup fails with "could not
# create bin directory '/home/runner/.cargo/bin': Permission denied".
RUN mkdir -p /home/runner/.cargo/registry /home/runner/.cargo/git \
      /home/runner/.cache/sccache /home/runner/.cache/yarn /home/runner/.cache/ms-playwright \
      /home/runner/.npm /home/runner/.local/share/pnpm/store \
 && chown -R runner:runner /home/runner/.cargo /home/runner/.cache /home/runner/.npm /home/runner/.local

# DinD: the base entrypoint starts dockerd (START_DOCKER_SERVICE=true) but does
# NOT wait for it to be ready. Wrap the runner CMD so it waits for docker before
# the runner accepts jobs — otherwise 'Checking docker version'/services: race a
# cold daemon.
RUN printf '%s\n' \
  '#!/usr/bin/env bash' \
  'set -Eeuo pipefail' \
  '[ "$#" -gt 0 ] || { echo "Runner command is missing" >&2; exit 1; }' \
  'command -v timeout >/dev/null || { echo "Docker readiness timeout tool is missing" >&2; exit 1; }' \
  '# Readiness only: the root entrypoint owns daemon startup, never this listener user.' \
  '# Twenty attempts, each at most two seconds plus one-second kill grace and backoff.' \
  'for ((attempt=0; attempt<20; attempt++)); do' \
  '  if timeout --kill-after=1s 2s docker info >/dev/null 2>&1; then exec "$@"; fi' \
  '  sleep 1' \
  'done' \
  'echo "Docker did not become ready within the startup budget" >&2' \
  'exit 1' \
  > /usr/local/bin/wait-docker.sh \
 && chmod +x /usr/local/bin/wait-docker.sh

# Health probe so ci-runner-farm can reap a runner whose GitHub registration was
# removed: its listener then loops forever on "Registration was not found /
# Retrying until reconnected" instead of exiting, so it never gets recycled and
# silently counts as idle capacity. Reports unhealthy ONLY in that stuck state —
# never a runner that is running a job or still starting.
RUN printf '%s\n' \
  '#!/usr/bin/env bash' \
  'set -uo pipefail' \
  '# Running a job => healthy, unconditionally (never interrupt a build).' \
  'pgrep -x Runner.Worker >/dev/null 2>&1 && exit 0' \
  '# No listener => nothing services jobs; recycle it.' \
  'pgrep -x Runner.Listener >/dev/null 2>&1 || exit 1' \
  '# Idle: require positive proof of a live session in the newest listener log.' \
  'log="$(ls -1t /actions-runner/_diag/Runner_*.log 2>/dev/null | head -1)"' \
  '[ -n "$log" ] || exit 0   # too early to tell; --start-period covers startup' \
  'last="$(grep -niE "Session created|Listening for Jobs|create session|connect error|Registration.*not found|has been removed|SessionConflict|SessionExpired|Retrying until reconnected|Runner listener exit" "$log" 2>/dev/null | tail -1)"' \
  'case "$last" in' \
  '  *"Session created"*|*"Listening for Jobs"*) exit 0 ;;  # connected' \
  '  "") exit 0 ;;                                          # inconclusive -> healthy' \
  '  *) exit 1 ;;                                           # stuck disconnected' \
  'esac' \
  > /usr/local/bin/runner-healthcheck.sh \
 && chmod +x /usr/local/bin/runner-healthcheck.sh
HEALTHCHECK --start-period=120s --interval=30s --timeout=10s --retries=3 \
  CMD ["/usr/local/bin/runner-healthcheck.sh"]

CMD ["/usr/local/bin/wait-docker.sh", "./bin/Runner.Listener", "run", "--startuptype", "service"]
